'use strict';

var MockMozVoicemail = {
  _number: null,
  getNumber: function() {
    return this._number;
  }
};
