'use strict';

/* exported MockPerformanceTestingHelper */

var MockPerformanceTestingHelper = {
  dispatch: function() {}
};
