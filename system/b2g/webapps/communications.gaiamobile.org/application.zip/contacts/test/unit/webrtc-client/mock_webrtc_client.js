'use strict';
/* exported MockWebrtcClient */

var MockWebrtcClient = {
  start: function() {},
  stop: function() {}
};
