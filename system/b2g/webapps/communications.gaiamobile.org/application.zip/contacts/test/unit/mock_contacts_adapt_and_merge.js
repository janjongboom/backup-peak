'use strict';

/* exported MockAdaptAndMerge */

var MockAdaptAndMerge = function (contact, matches, callbacks) {
  callbacks.error();
};

