'use strict';
/* exported MockContactDetails */

var MockContactDetails = {
  'init': function init() {},
  'render': function render() {},
  'setContact': function setContact(c) {}
};
