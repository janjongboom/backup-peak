'use strict';
/* exported MockExtFb */

var MockExtFb = {
  importFB: function() {},
  initEventHandlers: function(node, contact, linked) {}
};
