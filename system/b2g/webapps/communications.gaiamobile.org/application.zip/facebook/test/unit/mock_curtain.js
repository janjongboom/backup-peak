var Curtain = {
  show: function() {
    return {
      update: function() {

      }
    };
  },
  hide: function() {

  }
};
