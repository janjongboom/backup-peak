/**
 * Wraps navigator.battery for replacing it in unit tests more easily.
 */
define([],function() {
  

  return navigator.battery;
});
